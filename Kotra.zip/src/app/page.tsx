'use client'

import { useEffect } from 'react'

import { useRouter } from 'next/navigation'

import AOS from 'aos';
import 'aos/dist/aos.css';
import Button from '@mui/material/Button'

const Page = () => {
  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  const products = [
    { img:"chaevi.png", name: 'Chaevi', mainBusiness: 'EV Charging', website:'http://www.chaevi.com', catalog:'https://drive.google.com/drive/folders/1WJpREM68LIYCKPrtkJYFOjJTVthuq5S5?usp=sharing' },
    { img:"kevit.png", name: 'Korea Electric Vehicle Infra Technology (KEVIT)', mainBusiness: 'EV Charging', website:'https://www.kevit.co.kr/en', catalog:'https://drive.google.com/drive/folders/1FKPoJeq84jJJF6BAHg1z1nwV7cyAJn7m?usp=sharing' },
    { img:"poen.png", name: 'POEN Co., Ltd.', mainBusiness: 'EV Battery Re-manufacturing', website:'http://poen.co.kr/en/', catalog:'https://drive.google.com/drive/folders/1BDGF2pTvKe51V4ZZvfaVMLNVjl4GwpRA?usp=sharing' },
    { img:"e3mobility.png", name: 'E3 Mobility', mainBusiness: 'EV 2-wheeler', website:'http://www.e3mobilitygroup.com/', catalog:'https://drive.google.com/drive/folders/1dLbsLfGw78z2CAI0iDR8aD2FAw5k8vAC?usp=sharing' },
    { img:"daedong.png", name: 'Daedong Mobility Corporation', mainBusiness: 'EV 2-wheeler', website:'http://daedongmobility.co.kr', catalog:'https://drive.google.com/drive/folders/1RraJS4BE6R1ReBeU_SwJQ8lx5Q44LRi2?usp=sharing' },
    { img:"evar.png", name: 'EVAR', mainBusiness: 'EV Charging', website:'http://www.evar.co.kr', catalog:'https://drive.google.com/drive/folders/14tH-Mu-CDzvlptOqla9fH-kal8vB9RoY?usp=sharing' },
    { img:"voltaira.png", name: 'FIT Voltaira Korea', mainBusiness: 'Wiring Harness (EV 2-wheelers)', website:'https://www.voltaira-group.com/', catalog:'https://drive.google.com/drive/folders/1W2-tv6KmHbR_EV0Wxq4sak8urSYFEoDw?usp=sharing' },
    { img:"hyundaikefico.png", name: 'Hyundai Kefico', mainBusiness: 'EV 2-wheeler parts', website:'', catalog:'https://drive.google.com/drive/folders/1IwZ5TKkdyz3tIdTVEHluXkoREzxIMka5?usp=sharing' },
    { img:"hanhoecosti.png", name: 'HANHO ECOSTI', mainBusiness: 'Gear, Shaft', website:'http://hanhoinc.com', catalog:'https://drive.google.com/drive/folders/18-JoBbZWxyiiB76CUepJ9PDpiz5ONINV?usp=sharing' },
    { img:"costel.png", name: 'COSTEL', mainBusiness: 'EV Charging', website:'http://www.costel.com', catalog:'https://drive.google.com/drive/folders/1WXSZ0YVuovXjVhBMx0zqouh3lZqRJ5IZ?usp=sharing' },
    { img:"infac.png", name: 'INFAC CORPORATION', mainBusiness: 'Battery Module, System Assembly', website:'www.infac.com', catalog:'https://drive.google.com/drive/folders/1tID_iXkh68iUULzuRDv7lt_fOxvD7FCk?usp=sharing' },
    { img:"lg.png", name: 'LG Energy Solution', mainBusiness: 'Battery', website:'http://www.lgensol.com', catalog:'https://drive.google.com/drive/folders/16AtvnVJanI17BBRGeu6ztC31ejlOjrmq?usp=sharing' },
    { img:"motrex.png", name: 'MOTREX', mainBusiness: 'EV 2/4-wheeler parts', website:'http://motrex.co.kr', catalog:'https://drive.google.com/drive/folders/1V2qtU0jBPrZqNlkKEtke5F6jSMi6HBEw?usp=sharing' },
  ];

  const router = useRouter()

  // useEffect(() => {
  //   setMounted(typeof window !== 'undefined')
  // }, [])
  //
  // useEffect(() => {
  //   if (mounted) {
  //     router.push('/form')
  //   }
  // }, [mounted, router])

  return (
    <>
      <div className='bg-[#0B3A89]'>
        {/* Hero Section */}
        <section className="hero min-h-screen bg-cover bg-center bg-no-repeat relative"
                 style={{ backgroundImage: 'url(https://static.wixstatic.com/media/08d438_a7cfbce851da4b2cb7fd7b54a6ba57d3~mv2.jpg/v1/fill/w_1920,h_633,al_c,q_85,enc_auto/08d438_a7cfbce851da4b2cb7fd7b54a6ba57d3~mv2.jpg)' }}>

          {/* Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-transparent z-0"></div>

          {/* Glass Effect Container */}
          <div className="container mx-auto px-4 pt-4 flex flex-col items-center justify-center h-full relative z-10">
            <div
              className="bg-white bg-opacity-30 backdrop-blur-xl p-10 rounded-3xl text-center shadow-2xl transform transition-all duration-500 hover:scale-105 max-w-3xl">
              <h1 className="text-5xl font-extrabold text-white drop-shadow-2xl mb-4 animate-fade-in-up">
                Korea - Indonesia EV Business Partnership 2024
              </h1>
              <p className="text-lg text-gray-100 leading-relaxed">
                Dear Honorable Indonesian Business Partners,
                <br /><br />
                The Korea Trade-Investment Promotion Agency (KOTRA) is pleased to invite you to the upcoming ‘Korea -
                Indonesia EV Business Partnership.’ This event will serve as a key platform for fostering collaboration
                between Korean and Indonesian companies in the electric vehicle (EV) ecosystem sectors.
                <br /><br />
                The event will feature B2B meetings, offering participants the opportunity to engage directly with
                potential partners, explore business synergies, and discuss collaborative opportunities. Should you need
                any further information, please do not hesitate to contact
                <br />Ms. Tasya at +62-812-2161-0099 (WhatsApp), or
                <br />Ms. Adisty at +62-811-9125-084 (WhatsApp),
                <br /><br />
                We look forward to seeing you at <span className='font-bold'> Korea - Indonesia EV Business Partnership 2024!</span>
              </p>
              <Button
                onClick={() => {
                  router.push('/form')
                }}
                variant={'contained'}
                className="bg-blue-600 text-white px-8 py-3 rounded-full mt-8 hover:bg-blue-700 shadow-lg transform transition-all duration-300 hover:scale-105 focus:outline-none">
                Register Now
              </Button>
            </div>
          </div>
        </section>

        <section className="text-white products py-16 text-center bg-[#0B3A89] mx-4">
          <h2 className="text-4xl font-bold mb-12" data-aos="fade-right">Company Information</h2>
          <div className="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
            {products.map((product, index) => (
              <div key={index} className="bg-white bg-opacity-30 backdrop-blur-lg shadow-lg p-6" data-aos="fade-up">
                <img
                  src={`/images/logo/${product.img}`}
                  alt={product.name}
                  className="w-36 rounded-full object-cover mx-auto mb-6"
                />
                <h3 className="text-2xl font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-700 mb-4">{product.mainBusiness}</p>
                <div className="flex justify-center space-x-4">
                  {product.website && (
                    <a
                      href={product.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition"
                    >
                      Visit Website
                    </a>
                  )}
                  {product.catalog && (
                    <a
                      href={product.catalog}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-700 transition"
                    >
                      View Catalog
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  )
}

export default Page
